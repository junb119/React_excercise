import React, { Component, useEffect, useState } from 'react';
import './App.css';

let funcid = 0;

function App() {
  return (
    <div className="container">
     <h1>함수형, 클래스형 컴포넌트</h1>
     <FuncComp initNumber="2"/>
     <ClassComp initNumber="2"/>
    </div>
  );
}
function FuncComp(props) {
  const [number, setNumber] = useState(props.initNumber); //비구조할당 ES6
  const [date, setDate] = useState(new Date().toLocaleString()); 
  // console.log(new Date());
  // console.log(new Date().toLocaleString());

  useEffect(()=>{
    console.log('useEffect 실행', ++funcid); //마지막컴포넌트 렌더링된 후 실행
  },[]);  
  //[] 최초한번만 실행, [변수명] 최초한번은 실행되고,변수명의 값이 변경되면 실행

  console.log('컴포넌트실행',++funcid);
  /*
  let numberState = useState(props.initNumber); 
  let number = numberState[0]; //초기값 설정.
  let setNumber = numberState[1];  //초기값을 변경할 수 있는 함수
  */
  return (
    <div className="container">
     <h2>함수형 컴포넌트</h2>
     <p>Number: {number}</p>
     <p>Date: {date}</p>
     <input type="button" value="random" onClick={()=>{
          setNumber(Math.ceil(Math.random()*10));
        }}/>
     <input type="button" value="update" onClick={()=>{
          setDate(new Date().toLocaleString());
        }}/>
    </div>
  );
}
class ClassComp extends Component {
  /*
  UNSAFE_componentWillMount(){
    console.log('UNSAFE_componentWillMount 실행');
  }
  componentDidMount(){
    console.log('componentDidMount 실행');
  }
  shouldComponentUpdate(){
    console.log('shouldComponentUpdate 실행');
    return true;
  }
  UNSAFE_componentWillUpdate(){
    console.log('UNSAFE_componentWillUpdate 실행');
  }
  componentDidUpdate(){
    console.log('componentDidUpdate 실행');
  }
  */

  /*
  constructor(props){
    super(props);
    this.state={
      number: this.props.initNumber
    }
  }
  */
  state={
    number: this.props.initNumber,
    date:new Date().toLocaleString()
  }
  render() {
    console.log(this.props);
    return (
      <div className="container">
        <h2>클래스형 컴포넌트</h2>
        <p>Number: {this.state.number}</p>
        <p>Date: {this.state.date}</p>
        <input type="button" value="random" onClick={()=>{
          this.setState({
            number:Math.ceil(Math.random()*10)
          })
        }}/>
        <input type="button" value="update" onClick={()=>{
          this.setState({
            date:new Date().toLocaleString()
          })
        }}/>

      </div>
    )
  }
}

export default App;
